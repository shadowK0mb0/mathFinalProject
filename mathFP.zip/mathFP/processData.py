from openpyxl import load_workbook
import numpy as np
import datetime
import time
import matplotlib.pyplot as plt
wb = load_workbook('RedditData2.xlsx')
ws = wb["Sheet 1"]
A = np.array([[i.value for i in j] for j in ws['A2':'A2701']])
lenghtOfpost = np.array([[i.value for i in j] for j in ws['C2':'C2701']])
B = []
sum = 0


lenghtOfpost = np.rot90(lenghtOfpost)[0]

print(sum/len(A))
#print(A)
A = np.rot90(A)[0]
#print(A[1])
plt.figure(1)
plt.scatter(lenghtOfpost, A)
plt.show()


